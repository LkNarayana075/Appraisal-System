from .. import models, schemas
from fastapi import FastAPI, status, Depends, APIRouter
from sqlalchemy.orm import Session      
from ..database import get_db
from typing import List
from starlette.responses import Response  
from fastapi.exceptions import HTTPException


router = APIRouter(prefix='/discussion/api/v1',tags=['Discussion'])

@router.get('/discussion-list',response_model=List[schemas.Discussion])
def get_discussion_employee_list(db: Session = Depends(get_db)):
    discussion = db.query(models.Discussion).all()  
    return discussion


@router.get('/{id}',response_model=schemas.Discussion)
def get_employee_info(id:int,response:Response,db: Session = Depends(get_db)):
    discussion = db.query(models.Discussion).filter_by(employee_id=id).first()
    if not discussion:
        raise HTTPException(status.HTTP_404_NOT_FOUND,'Data Not Found')
    return discussion

@router.post('/need-discussion',status_code=status.HTTP_201_CREATED,response_model=schemas.Discussion)
def create_discussion(discussion : schemas.DiscussionCreate,db: Session = Depends(get_db)):
    new_discussion = models.Discussion(**discussion.dict())
    db.add(new_discussion)
    db.commit()
    db.refresh(new_discussion)
    return new_discussion

@router.patch('/close-discussion',response_model=schemas.Discussion)
def update_(id:int,discussion:schemas.DiscussionUpdate,db: Session = Depends(get_db)):
    discussion_query = db.query(models.Discussion).filter_by(id=id)

    if not discussion_query.first():
        raise HTTPException(status.HTTP_404_NOT_FOUND,'Data Not Found')
    discussion_query.update(discussion.dict(),synchronize_session=False)
    db.commit()
    return discussion_query.first()
