# from .. import models, schemas, utils, oauth2
# from fastapi import FastAPI, status, Depends, APIRouter
# from sqlalchemy.orm import Session
# from ..database import get_db    
# from starlette.responses import Response
# from fastapi.exceptions import HTTPException


# router = APIRouter(tags=['Auth'])


# @router.post('/login',response_model=schemas.Token)
# def login(user_cred:schemas.UserLogin,response:Response,db: Session = Depends(get_db)):
# 	user = db.query(models.User).filter_by(email=user_cred.email).first()
# 	if not user:
# 		raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,detail=f'Invalid Credentials')
# 	if not utils.verify(user_cred.password,user.password):
# 		raise HTTPException(status_code=status.HTTP_404_FORBIDDEN,detail=f'Invalid Credentials')
# 	return "logged in successfullly"