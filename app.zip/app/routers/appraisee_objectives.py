from .. import models, schemas, oauth2
from fastapi import FastAPI, status, Depends, APIRouter
from sqlalchemy.orm import Session      
from ..database import get_db
from typing import List
from starlette.responses import Response  
from fastapi.exceptions import HTTPException


router = APIRouter(prefix='/master/api/v1/appraisee_objective',tags=['Appraisee Objectives'])

@router.get('/',response_model=List[schemas.AppraiseeObjectives])
def get_all_appraisee_Objectives(db: Session = Depends(get_db)):
    appraisee_objectives = db.query(models.AppraiseeObjectives).all()  
    return appraisee_objectives


@router.get('/{appraisee_objective_id}',response_model=schemas.AppraiseeObjectives)
def get_appraisee_Objectives(appraisee_objective_id:int,response:Response,db: Session = Depends(get_db)):
    appraisee_objective = db.query(models.AppraiseeObjectives).filter_by(appraisee_objective_id=appraisee_objective_id).first()
    if not appraisee_objective:
        raise HTTPException(status.HTTP_404_NOT_FOUND,'Data Not Found')
    return appraisee_objective


@router.post('/{appraisee_objective_id}',status_code=status.HTTP_201_CREATED,response_model=schemas.AppraiseeObjectives)
def create_appraisee_objective(appraisee_objective : schemas.AppraiseeObjectivesCreate,db: Session = Depends(get_db)):
    new_appraisee_objective = models.AppraiseeObjectives(**appraisee_objective.dict())
    db.add(new_appraisee_objective)
    db.commit()
    db.refresh(new_appraisee_objective)
    return new_appraisee_objective

@router.delete('/{appraisee_objective_id}',status_code=status.HTTP_204_NO_CONTENT)
def delete_appraisee_objective(appraisee_objective_id:int,response:Response,db: Session = Depends(get_db)):
    appraisee_objective = db.query(models.AppraiseeObjectives).filter_by(appraisee_objective_id=appraisee_objective_id)
    if not appraisee_objective.first():
        raise HTTPException(status.HTTP_404_NOT_FOUND,'Data Not Found')
    appraisee_objective.delete(synchronize_session=False)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
        

@router.put('/{appraisee_objective_id}',response_model=schemas.AppraiseeObjectives)
def update_appraisee_objective(appraisee_objective_id:int,appraisee_objective:schemas.AppraiseeObjectivesUpdate,db: Session = Depends(get_db)):
    appraisee_objective_query = db.query(models.AppraiseeObjectives).filter_by(appraisee_objective_id=appraisee_objective_id)
    if not appraisee_objective_query.first():
        raise HTTPException(status.HTTP_404_NOT_FOUND,'Data Not Found')
    appraisee_objective_query.update(appraisee_objective.dict(),synchronize_session=False)
    db.commit()
    return appraisee_objective_query.first()
