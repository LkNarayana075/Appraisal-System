from .database import Base
from sqlalchemy import Column, Integer,String, Boolean, ForeignKey, Date
from sqlalchemy.sql.sqltypes import TIMESTAMP
from sqlalchemy.sql.expression import text
from sqlalchemy.orm import relationship


class Designation(Base):
	__tablename__ = 'designation'

	designation_id = Column(Integer,primary_key=True,nullable=False)
	designation_name = Column(String(75),nullable=False)
	designation_grade = Column(String(10),nullable=False)
	designation_description = Column(String(255),nullable=True)
	created_at = Column(TIMESTAMP(timezone=True),nullable=False,server_default=text('now()'))

class Department(Base):
	__tablename__ = 'department'

	department_id = Column(Integer,primary_key=True,nullable=False)
	department_name = Column(String(75),nullable=False)
	department_description = Column(String(255),nullable=True)
	created_at = Column(TIMESTAMP(timezone=True),nullable=False,server_default=text('now()'))

class Appraisee(Base):
	__tablename__ = 'appraisee'

	id = Column(Integer,primary_key=True,nullable=False)
	appraisee_id = Column(String(12),nullable=False,unique=True)
	first_name = Column(String(75),nullable=False)
	middle_name = Column(String(75),nullable=True)
	last_name = Column(String(75),nullable=False)
	password = Column(String(75),nullable=False)
	email_id = Column(String(150),nullable=False) 
	mobile_number = Column(String(15),nullable=False)
	joining_date = Column(Date,nullable=False)
	location = Column(String(25),nullable=False)
	status = Column(Boolean,nullable=False,default=True)
	last_access_date = Column(Date,nullable=False)
	created_at = Column(TIMESTAMP(timezone=True),server_default=text('now()'))
	designation_id = Column(Integer,ForeignKey("designation.designation_id",ondelete="CASCADE"),nullable=False)
	department_id = Column(Integer,ForeignKey("department.department_id",ondelete="CASCADE"),nullable=False)
	department = relationship("Department")
	designation = relationship("Designation")
	

#Appraisal Calendar
class AppraisalCalendar(Base):
	__tablename__ = 'appraisal_calendar'

	calendar_id = Column(Integer,primary_key=True,nullable=False)
	appraisal_term = Column(Integer,nullable=False)
	objective_set_date = Column(Date,nullable=False)
	self_appraisal_end_date = Column(Date,nullable=False)
	review_end_date = Column(Date,nullable=False)
	closer_date = Column(Date,nullable=False)
	rating_scale = Column(Integer,nullable=False)
	comments = Column(String(255),nullable=False)
	status = Column(Boolean,nullable=False)
	qualification_criteria = Column(Integer,nullable=False)
	created_at = Column(TIMESTAMP(timezone=True),nullable=False,server_default=text('now()'))
	approved_by = Column(Integer,ForeignKey("appraisee.id",ondelete="CASCADE"),nullable=False)
	appraisee = relationship("Appraisee")

# Employee Appraisers
class EmployeeAppraisers(Base):
    __tablename__ = 'employee_appraisers'
    
    id = Column(Integer,primary_key=True,nullable=False)
    appraisee_id = Column(Integer,ForeignKey("appraisee.id",ondelete="CASCADE"),nullable=False)
    appraiser_id = Column(Integer,ForeignKey("appraisee.id",ondelete="CASCADE"),nullable=False)
    calendar_id = Column(Integer,ForeignKey("appraisal_calendar.calendar_id",ondelete="CASCADE"),nullable=False)
    appraisee = relationship("Appraisee", foreign_keys="EmployeeAppraisers.appraisee_id")
    appraiser = relationship("Appraisee",foreign_keys="EmployeeAppraisers.appraiser_id")
    calendar = relationship("AppraisalCalendar")
  
#objective
class Objective(Base):
	__tablename__ = 'objective'

	objective_id = Column(String(40),primary_key=True,nullable=False)
	objective_name = Column(String(75),nullable=False)
	objective_description = Column(String(255),nullable=True)
	created_at = Column(TIMESTAMP(timezone=True),nullable=False,server_default=text('now()'))


class AppraiseeObjectives(Base):
    __tablename__ = 'appraisee_objectives'
    
    appraisee_objective_id = Column(Integer,primary_key=True,nullable=False)
    appraisee_id = Column(Integer,ForeignKey("appraisee.id",ondelete="CASCADE"),nullable=False)
    calendar_id = Column(Integer,ForeignKey("appraisal_calendar.calendar_id",ondelete="CASCADE"),nullable=False)
    objective_id = Column(String(40),ForeignKey("objective.objective_id",ondelete="CASCADE"),nullable=False)
    weightage = Column(String,nullable=True)
    status = Column(Integer,nullable=True)
    created_at = Column(TIMESTAMP(timezone=True),nullable=False,server_default=text('now()'))
    appraisee = relationship("Appraisee")
    calendar = relationship("AppraisalCalendar")
    objective = relationship("Objective")


class AppraisalRating(Base):
	__tablename__ = 'appraisal_rating'

	appraisal_rating_id = Column(Integer,primary_key=True,nullable=False)
	appraisal_objective_id = Column(Integer,ForeignKey("appraisee_objectives.appraisee_objective_id",ondelete="CASCADE"),nullable=False)
	rating = Column(Integer,nullable=False)
	type = Column(String,nullable=False)
	created_at = Column(TIMESTAMP(timezone=True),nullable=False,server_default=text('now()'))
	appraisal_objective = relationship("AppraiseeObjectives")


class Discussion(Base):
    __tablename__ = 'discussion'

    discussion_id = Column(Integer,primary_key=True,nullable=False)
    discussion_description = Column(String(255),nullable=False)
    appraisee_id = Column(Integer,ForeignKey("appraisee.id",ondelete="CASCADE"),nullable=False)
    calendar_id = Column(Integer,ForeignKey("appraisal_calendar.calendar_id",ondelete="CASCADE"),nullable=False)
    status = Column(Integer,nullable=False)
    comments = Column(String(255),nullable=False)
    scheduled_date = Column(Date,nullable=False)
    created_at = Column(TIMESTAMP(timezone=True),nullable=False,server_default=text('now()'))
    appraisee = relationship("Appraisee")
    calendar = relationship("AppraisalCalendar")



class Authorities(Base):
	__tablename__ = 'authorities'

	authority_id = Column(Integer,primary_key=True,nullable=False)
	authority_name = Column(String(255),nullable=False)
	created_at = Column(TIMESTAMP(timezone=True),nullable=False,server_default=text('now()'))


class Role(Base):
	__tablename__ = 'role'

	role_id = Column(Integer,primary_key=True,nullable=False)
	role_name = Column(String(75),nullable=False)
	created_at = Column(TIMESTAMP(timezone=True),nullable=False,server_default=text('now()'))


class  RoleAuthorities(Base):
    __tablename__= 'role_authorities'	
    
    role_id = Column(Integer,ForeignKey("role.role_id",ondelete="CASCADE"),nullable=False,primary_key=True)
    authority_id = Column(Integer,ForeignKey("authorities.authority_id",ondelete="CASCADE"),nullable=False,primary_key=True)
    authority = relationship("Authorities")
    role = relationship("Role")




class  UserRoles(Base):
    __tablename__= 'user_roles'
    
    appraisee_id = Column(Integer,ForeignKey("appraisee.id",ondelete="CASCADE"),nullable=False,primary_key=True)
    role_id = Column(Integer,ForeignKey("role.role_id",ondelete="CASCADE"),nullable=False,primary_key=True)
    role = relationship("Role")
    appraisee = relationship("Appraisee")




class  EmployeeAppraisal(Base):
    __tablename__= 'employee_appraisal'
    
    id = Column(Integer,primary_key=True,nullable=False)
    appraisee_id = Column(Integer,ForeignKey("appraisee.id",ondelete="CASCADE"),nullable=False)
    calendar_id = Column(Integer,ForeignKey("appraisal_calendar.calendar_id",ondelete="CASCADE"),nullable=False)
    appraiser_id = Column(Integer,ForeignKey("appraisee.id",ondelete="CASCADE"),nullable=False)
    appraisee_total_rating = Column(Integer,nullable=False)
    appraiser_total_rating = Column(Integer,nullable=False)
    normalized_total_rating = Column(Integer,nullable=False)
    created_at = Column(TIMESTAMP(timezone=True),nullable=False,server_default=text('now()'))
    appraisee = relationship("Appraisee", foreign_keys="EmployeeAppraisal.appraisee_id")
    calendar = relationship("AppraisalCalendar")
    appraiser = relationship("Appraisee", foreign_keys="EmployeeAppraisal.appraiser_id")
    
    