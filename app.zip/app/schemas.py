from pydantic import BaseModel, EmailStr
from datetime import datetime, date
from typing import Optional,List


#Designation
class DesignationBase(BaseModel):
    designation_name: str
    designation_grade: str
    designation_description: str

class DesignationCreate(DesignationBase):
    pass

class DesignationUpdate(DesignationBase):
    pass
   
class Designation(DesignationBase):
    designation_id: int
    created_at: datetime

    class Config:
        orm_mode = True

#Department
class DepartmentBase(BaseModel):
    department_name: str
    department_description: str

class DepartmentCreate(DepartmentBase):
    pass

class DepartmentUpdate(DepartmentBase):
    pass
   
class Department(DepartmentBase):
    department_id: int
    created_at: datetime

    class Config:
        orm_mode = True

#Appraisee
class AppraiseeBase(BaseModel):
    appraisee_id : str
    first_name: str
    middle_name: str
    last_name : str
    password : str
    email_id : EmailStr
    mobile_number :str 
    joining_date : date
    location : str
    status : bool
    last_access_date : date

class AppraiseeCreate(AppraiseeBase):
    department_id : int
    designation_id : int

class AppraiseeUpdate(AppraiseeBase):
    department_id : int
    designation_id : int

class Appraisee(AppraiseeBase):
    id : int
    department: Department
    designation : Designation
    created_at: datetime

    class Config:
        orm_mode = True

#Calendar
class CalendarBase(BaseModel):
    appraisal_term: int
    objective_set_date:date
    self_appraisal_end_date:date
    review_end_date:date
    closer_date:date
    rating_scale:int
    status: bool
    qualification_criteria:int
    comments:str

class  CalendarCreate(CalendarBase):
    approved_by:int

class  CalendarUpdate(CalendarBase):
    approved_by:int

class  Calendar(CalendarBase):
    calendar_id: int
    appraisee: Appraisee 
    created_at: datetime
    
    class Config:
        orm_mode = True

# Employee Appraisers
class EmployeeAppraiserBase(BaseModel):
    pass
    

class  EmployeeAppraiserCreate(EmployeeAppraiserBase):
    appraisee_id: int
    appraiser_id: int
    calendar_id: int

class  EmployeeAppraiserUpdate(EmployeeAppraiserBase):
    appraisee_id: int
    appraiser_id: int
    calendar_id: int

class  EmployeeAppraiser(EmployeeAppraiserBase):
    id: int
    appraisee: Appraisee 
    appraiser: Appraisee
    calendar: Calendar
    
    class Config:
        orm_mode = True

# Objective
class ObjectiveBase(BaseModel):
    objective_name : str
    objective_description : str    

class ObjectiveCreate(ObjectiveBase):
    pass
    

class ObjectiveUpdate(ObjectiveBase):
    pass

class Objective(ObjectiveBase):
    objective_id : str 
    created_at: datetime

    class Config:
        orm_mode = True

#Appraisee Objectives
class AppraiseeObjectivesBase(BaseModel):
    weightage: str
    status: int

class AppraiseeObjectivesCreate(AppraiseeObjectivesBase):
    appraisee_id: int
    objective_id: str
    calendar_id: int

class AppraiseeObjectivesUpdate(AppraiseeObjectivesBase):
    appraisee_id: int
    objective_id: str
    calendar_id: int
   
class AppraiseeObjectives(AppraiseeObjectivesBase):
    appraisee_objective_id: int
    created_at: datetime
    appraisee: Appraisee
    calendar: Calendar
    objective: Objective

    class Config:
        orm_mode = True

# Appraisal Rating
class AppraisalRatingBase(BaseModel):
    rating : int
    type: str

class Appraisalrating_create(AppraisalRatingBase):
    appraisal_objective_id: int

class AppraisalUpdate(AppraisalRatingBase):
    appraisal_objective_id: int

class Appraisalrating(AppraisalRatingBase):
    appraisal_rating_id: int
    appraisal_objective: AppraiseeObjectives
    created_at: datetime    

    class Config:
        orm_mode = True

# Discussion

class DiscussionBase(BaseModel):
    discussion_description : str
    status : int
    scheduled_date : date
    comments : str


class DiscussionCreate(DiscussionBase):
    appraisee_id : int
    calendar_id : int

class DiscussionUpdate(DiscussionBase):
    appraisee_id : int
    calendar_id : int


class Discussion(DiscussionBase):
    discussion_id : int
    created_at: datetime
    appraisee : Appraisee
    calendar : Calendar

    class Config:
        orm_mode = True

# Authorities

class Authorities(BaseModel):
    authority_name:str

class AuthoritiesCreate(Authorities):
    pass

class AuthoritiesOut(Authorities):
    authority_id:int
    created_at: datetime

    class Config:
        orm_mode = True

# Role
class Role(BaseModel):
    role_name:str

class RoleCreate(Role):
    pass

class RoleOut(Role):
    role_id:int
    created_at: datetime

    class Config:
        orm_mode = True


#Role Authorities
class RoleAuthoritiesOut(BaseModel):
    role : RoleOut
    authority : AuthoritiesOut 
    
    class Config:
        orm_mode = True
class RoleAuthoritiesCreate(BaseModel):
    role_id:int  
    authority_id:int

# user Roles
class UserRolesBase(BaseModel):
    pass

class UserRolesCreate(UserRolesBase):
    appraisee_id: int
    role_id : int

class UserRolesUpdate(UserRolesBase):
    appraisee_id: int
    role_id : int

   
class UserRoles(UserRolesBase):
    role: RoleOut
    appraisee: Appraisee

    class Config:
        orm_mode = True
        
 
# Employee Appraisal

class EmployeeAppraisalBase(BaseModel):
    appraisee_total_rating: int
    appraiser_total_rating: int
    normalized_total_rating: int

class EmployeeAppraisalCreate(EmployeeAppraisalBase):
    appraisee_id: int
    calendar_id: int
    appraiser_id: int

class EmployeeAppraisalUpdate(EmployeeAppraisalBase):
    appraisee_id: int
    calendar_id: int
    appraiser_id: int
   
class EmployeeAppraisal(EmployeeAppraisalBase):
    id: int
    created_at: datetime
    appraisee : Appraisee
    calendar: Calendar
    appraiser : Appraisee 

    class Config:
        orm_mode = True

 

class AppraiseByDeptDesg(BaseModel):
    department_id:int
    designation_id:int

class AppraiseByDeptDesgOut(BaseModel):
    pass

      
class TokenData(BaseModel):
    id: Optional[str] = None

class Token(BaseModel):
    access_token:str 
    token_type:str

class TokenData(BaseModel):
    id: Optional[str]
       